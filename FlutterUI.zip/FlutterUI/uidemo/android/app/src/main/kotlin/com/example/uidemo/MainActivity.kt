package com.example.uidemo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
